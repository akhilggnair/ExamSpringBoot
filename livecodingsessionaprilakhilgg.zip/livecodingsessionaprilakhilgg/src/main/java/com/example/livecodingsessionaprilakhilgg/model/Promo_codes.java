package com.example.livecodingsessionaprilakhilgg.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Promo_codes {

	
	@Id
	private String code;
	private String discount_percentage;
	private String active;
	private Date  valid_until;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDiscount_percentage() {
		return discount_percentage;
	}
	public void setDiscount_percentage(String discount_percentage) {
		this.discount_percentage = discount_percentage;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public Date getValid_until() {
		return valid_until;
	}
	public void setValid_until(Date valid_until) {
		this.valid_until = valid_until;
	}
	
}



//-- Sample Promo Codes
//INSERT INTO promo_codes (code, discount_percentage, active, valid_until) VALUES
//('SPRING25', 25.00, TRUE, '2025-06-30'),
//('WELCOME10', 10.00, TRUE, '2025-12-31'),
//('FLASH15', 15.00, TRUE, '2025-04-15'),
//('SUMMER20', 20.00, FALSE, '2025-05-01');
//