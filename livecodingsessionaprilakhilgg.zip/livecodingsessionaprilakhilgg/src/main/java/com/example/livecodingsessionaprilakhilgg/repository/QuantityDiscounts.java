package com.example.livecodingsessionaprilakhilgg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.livecodingsessionaprilakhilgg.model.Quantity_discounts;

public interface QuantityDiscounts extends JpaRepository<Quantity_discounts, Integer> {

	
	@Query("SELECT q FROM Quantity_discounts q WHERE q.min_quantity = :min_quantity")
    public Quantity_discounts getByMin_quantity(@Param("min_quantity") int min_quantity);
	
}
