package com.example.livecodingsessionaprilakhilgg.model;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Quantity_discounts {

	@Id
	private int id;
	private int min_quantity;
	private float discount_percentage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMin_quantity() {
		return min_quantity;
	}
	public void setMin_quantity(int min_quantity) {
		this.min_quantity = min_quantity;
	}
	public float getDiscount_percentage() {
		return discount_percentage;
	}
	public void setDiscount_percentage(float discount_percentage) {
		this.discount_percentage = discount_percentage;
	}
	
	
}



//-- Sample Quantity Discount Rules
//INSERT INTO quantity_discounts (min_quantity, discount_percentage) VALUES
//(3, 5.00),
//(5, 7.50),
//(10, 12.00);