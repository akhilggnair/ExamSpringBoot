package com.example.livecodingsessionaprilakhilgg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.livecodingsessionaprilakhilgg.model.User_types;

public interface UserTypesRepo extends JpaRepository<User_types , String > {

	
	public User_types getByType(String type);
	
}
