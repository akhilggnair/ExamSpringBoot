package com.example.livecodingsessionaprilakhilgg.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.livecodingsessionaprilakhilgg.model.Products;
import com.example.livecodingsessionaprilakhilgg.model.Promo_codes;
import com.example.livecodingsessionaprilakhilgg.model.Quantity_discounts;
import com.example.livecodingsessionaprilakhilgg.model.User_types;
import com.example.livecodingsessionaprilakhilgg.repository.ProductRepository;
import com.example.livecodingsessionaprilakhilgg.repository.PromoCodeRepository;
import com.example.livecodingsessionaprilakhilgg.repository.QuantityDiscounts;
import com.example.livecodingsessionaprilakhilgg.repository.UserTypesRepo;

@Service
public class ServiceImpl implements ServiceInterface {

	@Autowired
	ProductRepository proRepo;

	@Autowired
	QuantityDiscounts quaRepo;

	@Autowired
	PromoCodeRepository promoRepo;

	@Autowired
	UserTypesRepo userTpyeRepo;

	@Override
	public Products getProducts(String id) {

		Optional<Products> pro = proRepo.findById(id);

		Products pro1 = null;

		if (pro.isPresent()) {

			pro1 = pro.get();
		}

		return pro1;
	}

	@Override
	public Quantity_discounts getQuantity(int Quantity) {

		Quantity_discounts quantity = quaRepo.getByMin_quantity(Quantity);

		if (null != quantity) {

			return quantity;
		} else {
			return null;
		}

	}

	@Override
	public Promo_codes getByPromoCode(String code) {

		Promo_codes promo = promoRepo.getByCode(code);

		if (null != promo) {

			return promo;
		} else {
			return null;
		}

	}

	@Override
	public User_types getTypes(String type) {



		User_types types = userTpyeRepo.getByType(type);
		if (null != types) {

			return types;
		} else {
			return null;
		}
	}
}
