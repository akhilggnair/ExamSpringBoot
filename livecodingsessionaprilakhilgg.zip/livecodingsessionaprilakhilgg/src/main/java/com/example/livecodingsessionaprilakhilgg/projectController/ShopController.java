package com.example.livecodingsessionaprilakhilgg.projectController;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.livecodingsessionaprilakhilgg.model.AppliedDiscounts;
import com.example.livecodingsessionaprilakhilgg.model.Products;
import com.example.livecodingsessionaprilakhilgg.model.ProductsDto;
import com.example.livecodingsessionaprilakhilgg.model.Promo_codes;
import com.example.livecodingsessionaprilakhilgg.model.Quantity_discounts;
import com.example.livecodingsessionaprilakhilgg.model.User_types;
import com.example.livecodingsessionaprilakhilgg.service.ServiceInterface;

@RestController
@RequestMapping("/api/products")
public class ShopController {
	
	@Autowired
	ServiceInterface service;
	
	
	@GetMapping("/price-calculation")
public ResponseEntity<?> productDetails(@RequestParam("productId") String productId,
		@RequestParam("quantity") int quantity,@RequestParam("promoCode")String promoCode,@RequestParam("userType") String userType){
	
		ProductsDto dto=new ProductsDto();
		AppliedDiscounts disc=new AppliedDiscounts();
		
		try {
			Products pro=service.getProducts(productId);
			Quantity_discounts dis=service.getQuantity(quantity);
			Promo_codes code=service.getByPromoCode(promoCode);
			User_types user=service.getTypes(userType);
			
			
			if(null!=pro) {
				dto.setProductId(pro.getId());
				dto.setOriginalPrice(pro.getBase_price());
				
				
				
				int basePrice=Integer.parseInt(pro.getBase_price());
				
				BigDecimal dec= new BigDecimal(pro.getBase_price());
				
				int basePrice1=dec.intValue();
				
				
				
				float discount = dis.getDiscount_percentage();
				float finalPrice = basePrice - (basePrice * discount / 100);

				
				float savings=basePrice1-finalPrice;
						dto.setTotalSavings(savings);
				dto.setFinalPrice(finalPrice);
				dto.setTotalSavings(savings);
				disc.setCodes(code);
				disc.setTypes(user);
				
				
				
			dto.setDis(disc);
			
			
			

			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	
	
	return ResponseEntity.ok(dto);
	
}
	
	
	

}
