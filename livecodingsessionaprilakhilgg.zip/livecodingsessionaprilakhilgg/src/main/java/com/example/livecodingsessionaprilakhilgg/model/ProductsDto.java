package com.example.livecodingsessionaprilakhilgg.model;



public class ProductsDto {
	
private String productId;
private String originalPrice;
	private  float finalPrice;
	private float totalSavings;
	
	private AppliedDiscounts dis;
	public AppliedDiscounts getDis() {
		return dis;
	}
	public void setDis(AppliedDiscounts dis) {
		this.dis = dis;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getOriginalPrice() {
		return originalPrice;
	}
	public void setOriginalPrice(String originalPrice) {
		this.originalPrice = originalPrice;
	}
	
	public float getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(float finalPrice) {
		this.finalPrice = finalPrice;
	}
	public float getTotalSavings() {
		return totalSavings;
	}
	public void setTotalSavings(float totalSavings) {
		this.totalSavings = totalSavings;
	}
	
}
