package com.example.livecodingsessionaprilakhilgg.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User_types {
	@Id
	private String type;
	private String discount_percentage;

}
//-- Sample User Types
//INSERT INTO user_types (type, discount_percentage) VALUES
//('REGULAR', 0.00),
//('PREMIUM', 10.00),
//('VIP', 15.00);
//