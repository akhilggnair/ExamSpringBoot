package com.example.livecodingsessionaprilakhilgg.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Products {
	@Id
	private String id;
	private String name;
	private String description;
	
	private String base_price;
	private String category ;
	private String available_quantity;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBase_price() {
		return base_price;
	}
	public void setBase_price(String base_price) {
		this.base_price = base_price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getAvailable_quantity() {
		return available_quantity;
	}
	public void setAvailable_quantity(String available_quantity) {
		this.available_quantity = available_quantity;
	}

}



//INSERT INTO products (id, name, description, base_price, category, available_quantity) VALUES
//('ABC123', 'Premium Headphones', 'Noise-cancelling wireless headphones', 99.99, 'ELECTRONICS', 50),
//('DEF456', 'Fitness Tracker', 'Smart fitness and health tracker', 59.95, 'WEARABLES', 100),
//('GHI789', 'Coffee Maker', 'Programmable drip coffee maker', 45.50, 'HOME', 30),
//('JKL012', 'Backpack', 'Water-resistant laptop backpack', 35.99, 'ACCESSORIES', 200),
//('MNO345', 'Wireless Mouse', 'Ergonomic wireless mouse', 24.99, 'ELECTRONICS', 150),
//('PQR678', 'Yoga Mat', 'Non-slip exercise yoga mat', 29.95, 'FITNESS', 80),
//('STU901', 'Water Bottle', 'Insulated stainless steel water bottle', 18.50, 'ACCESSORIES', 250),
//('VWX234', 'Desk Lamp', 'LED desk lamp with adjustable brightness', 32.99, 'HOME', 45),
//('YZA567', 'Bluetooth Speaker', 'Portable wireless bluetooth speaker', 49.99, 'ELECTRONICS', 60),
//('BCD890', 'Protein Powder', 'Whey protein supplement', 39.95, 'FITNESS', 75);
//


