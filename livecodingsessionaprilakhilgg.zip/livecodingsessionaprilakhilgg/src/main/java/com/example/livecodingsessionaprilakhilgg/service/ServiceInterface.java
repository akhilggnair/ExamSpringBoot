package com.example.livecodingsessionaprilakhilgg.service;

import com.example.livecodingsessionaprilakhilgg.model.Products;
import com.example.livecodingsessionaprilakhilgg.model.Promo_codes;
import com.example.livecodingsessionaprilakhilgg.model.Quantity_discounts;
import com.example.livecodingsessionaprilakhilgg.model.User_types;

public interface ServiceInterface {
	
	public Products getProducts( String id);
	
	public Quantity_discounts getQuantity(int Quantity);
	
	public Promo_codes getByPromoCode(String code);
	
	public User_types getTypes(String type);

}
