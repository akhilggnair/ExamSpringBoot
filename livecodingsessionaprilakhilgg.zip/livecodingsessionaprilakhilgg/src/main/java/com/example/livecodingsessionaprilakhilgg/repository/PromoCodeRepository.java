package com.example.livecodingsessionaprilakhilgg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.livecodingsessionaprilakhilgg.model.Promo_codes;

public interface PromoCodeRepository  extends JpaRepository<Promo_codes, String>{

	public Promo_codes getByCode(String code);
}
