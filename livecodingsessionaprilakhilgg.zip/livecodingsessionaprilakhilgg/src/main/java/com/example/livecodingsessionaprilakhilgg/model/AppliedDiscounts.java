package com.example.livecodingsessionaprilakhilgg.model;

public class AppliedDiscounts {

	public Promo_codes codes;
	public User_types types;
	public Promo_codes getCodes() {
		return codes;
	}
	public void setCodes(Promo_codes codes) {
		this.codes = codes;
	}
	public User_types getTypes() {
		return types;
	}
	public void setTypes(User_types types) {
		this.types = types;
	}
}
