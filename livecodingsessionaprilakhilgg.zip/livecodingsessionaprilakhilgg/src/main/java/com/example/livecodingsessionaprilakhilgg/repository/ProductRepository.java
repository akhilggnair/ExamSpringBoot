package com.example.livecodingsessionaprilakhilgg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.livecodingsessionaprilakhilgg.model.Products;

public interface ProductRepository extends JpaRepository<Products, String>{

}
