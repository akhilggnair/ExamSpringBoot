package com.example.livecodingsessionaprilakhilgg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivecodingsessionaprilakhilggApplicationTests {

	@Test
	void contextLoads() {
	}

}
