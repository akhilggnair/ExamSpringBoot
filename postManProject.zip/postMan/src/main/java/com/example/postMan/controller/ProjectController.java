package com.example.postMan.controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.postMan.model.Department;
import com.example.postMan.model.Student;
import com.example.postMan.sevice.ServiceInterface;

@RestController
@CrossOrigin("*")
public class ProjectController {
	@Autowired
	ServiceInterface service;
	
	 @GetMapping("/welcome")
	    public ResponseEntity<String> getWelcomeMessage() {
	        String message = "Welcome to the Project!";
	        return ResponseEntity.ok(message);  	    
	        }
	 
	 @PostMapping("/add")
	    public ResponseEntity<?> addStudentUsingRequestParam(
	    		@RequestBody Student std
	    		) {
		 
		 int id=std.getDepartment().getId();
		 
		 
	 std=service.add(std);

        return null;
	    }
	 
	 
	 @GetMapping("/view")
	 public ResponseEntity<?>GetStudent(@RequestParam("id") int id){
		 
		 Optional<Student> std=service.getStudent(id);
		 
		 Student std1=null;
		 
		 if (std.isPresent()) {
			 std1 = std.get();
		    
		 }
		 
		 
		 return ResponseEntity.ok(std1);
	 }
	    @GetMapping("/list")
	    public ResponseEntity<?> findAllStudent(){
	    	
	    	
	    	 List<Student> students = service.getAllSTudent();
	    	    return ResponseEntity.ok(students);
	    }
	    
	    @GetMapping("/login")
	    public ResponseEntity<?> login(@RequestParam("username") String username,@RequestParam("password") String password){
	    	
	    	Optional<Student> std=service.login(username, password);
	    	
	    	Student std1=null;
	    	
	    	
	    	if(std.isPresent()) {
	    		 std1 = std.get();
	    		 return ResponseEntity.ok(std1);
	    	}else {
	    		return ResponseEntity.ok("Login Failed");
	    	}
	    	
	    	 
	    }
	    
	    @GetMapping("/getAllDepartMent")
	    public List<Department>getAllDepartment(){
	    	
	    	
	    	List<Department> depart = service.getAllDepartments();
	    	
    	    return depart;
		
	    	
	    }
	 
	 
	 

}
