package com.example.postMan.sevice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.postMan.model.Department;
import com.example.postMan.model.Student;
import com.example.postMan.repository.DepartmentRepo;
import com.example.postMan.repository.StudentRepo;

@Service
public class ServiceImpl implements ServiceInterface{
	@Autowired
	StudentRepo stdRepo;
	
	@Autowired
	DepartmentRepo depRepo;
	
	
	
	
	@Override
	public Student add(Student std) {
		
		return stdRepo.save(std);
	}


	@Override
	public Optional<Department> getDepartMent(int id) {
		
		return depRepo.findById(id);
	}


	@Override
	public Optional<Student> getStudent(int id) {
		
		return stdRepo.findById(id);
	}


	@Override
	public List<Student> getAllSTudent() {
		
		return stdRepo.findAll();
	}


	@Override
	public Optional<Student> login(String username, String password) {
		
		return stdRepo.findByUsernameAndPassword(username, password);
	}


	@Override
	public List<Department> getAllDepartments() {
		
		return depRepo.findAll() ;
	}

}
