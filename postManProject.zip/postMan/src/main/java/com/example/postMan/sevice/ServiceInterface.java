package com.example.postMan.sevice;

import java.util.List;
import java.util.Optional;

import com.example.postMan.model.Department;
import com.example.postMan.model.Student;

public interface ServiceInterface {
	
	public Student add(Student std) ;
	
	public Optional<Department> getDepartMent(int id);
	
	public Optional<Student>getStudent(int id);
	
	public List<Student>getAllSTudent();
	
	public Optional<Student> login(String username,String password);
	
	public List<Department>getAllDepartments();

}
