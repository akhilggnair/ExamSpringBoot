package com.example.postMan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostManApplicationTests {

	@Test
	void contextLoads() {
	}

}
